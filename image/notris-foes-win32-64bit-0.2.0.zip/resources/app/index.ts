#!/usr/bin/env electron
import { app, BrowserWindow } from 'electron';
import * as path from 'path';

let pluginName: string;
switch (process.platform) {
    default:
    case 'linux':
        pluginName = 'libpepflashplayer.so';
        break;
    case 'darwin':
        pluginName = 'PepperFlashPlayer.plugin';
        break;
    case 'win32':
        pluginName = 'pepflashplayer32_32_0_0_465.dll';
        break;
}

app.commandLine.appendSwitch('ppapi-flash-path', path.join(__dirname, pluginName));
app.commandLine.appendSwitch('no-sandbox');

export default class Main {
    private readonly application: Electron.App;
    private mainWindow: BrowserWindow | undefined;

    public constructor() {
        this.application = app;
        this.application.on('window-all-closed', this.onWindowAllClosed.bind(this));
        this.application.on('ready', this.onReady.bind(this));
        this.application.on('certificate-error', (event, webContents, url, error, certificate, callback) => {
            event.preventDefault();
            callback(true);
        });
    }

    private onWindowAllClosed(): void {
        this.application.quit();
    }

    private onReady(): void {
        this.mainWindow = new BrowserWindow({
            width: 800,
            height: 600,
            webPreferences: {
                plugins: true,
            }
        });
        this.mainWindow.loadURL('https://notrisfoes.com/');
    }

}

new Main();
